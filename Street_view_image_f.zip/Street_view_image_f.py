import requests
from lat_log import new_coordinates
API_KEY = 'AIzaSyB6kachauOAaOJeIvm1P2dFdv4qOSPxaOs'

def fetch_street_view_image(lat, lon, save_path):
    url = f"https://maps.googleapis.com/maps/api/streetview?size=600x300&location={lat},{lon}&key={API_KEY}"
    response = requests.get(url)
    
    if response.status_code == 200:
        with open(save_path, 'wb') as f:
            f.write(response.content)
    else:
        print(f"Failed to fetch image for {lat}, {lon}")

# Fetch images for each interpolated coordinate
for idx, (lat, lon) in enumerate(new_coordinates):
    save_path = f"노선명_{idx}.jpg"
    fetch_street_view_image(lat, lon, save_path)
