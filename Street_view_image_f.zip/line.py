import pandas as pd
from geopy.distance import geodesic

# CSV 파일에서 버스 노선 데이터 로드
# CP949 인코딩을 사용하여 한글 처리
data = pd.read_csv(r'C:\Users\user\Desktop\kn\독산,시흥.csv', encoding='cp949')
print(data.head())  # 데이터 로드 확인

# 한글 인코딩 문제 해결
# UTF-8로 변환하여 깨진 문자 처리
data['노선명'] = data['노선명'].apply(lambda x: x.encode('cp949').decode('utf-8', errors='ignore'))

def generate_points_every_30m(start_lat, start_lon, end_lat, end_lon, interval=30):
    """
    두 지점 사이의 경로를 일정 간격으로 분할하여 중간 지점들을 생성하는 함수
    
    매개변수:
        start_lat (float): 시작점 위도
        start_lon (float): 시작점 경도
        end_lat (float): 종점 위도
        end_lon (float): 종점 경도
        interval (int): 분할 간격(미터), 기본값 30m
        
    반환값:
        list: (위도, 경도) 튜플로 구성된 중간 지점들의 리스트
    """
    points = []
    start = (start_lat, start_lon)
    end = (end_lat, end_lon)
    
    # geodesic을 사용하여 두 지점 간 실제 거리 계산(미터 단위)
    total_distance = geodesic(start, end).meters
    
    # 총 거리를 기반으로 필요한 분할 수 계산
    num_intervals = int(total_distance // interval)
    
    # 선형 보간법을 사용하여 중간 지점들 생성
    for i in range(1, num_intervals + 1):
        fraction = i / num_intervals
        # 위도와 경도를 비율에 따라 계산
        lat = start_lat + fraction * (end_lat - start_lat)
        lon = start_lon + fraction * (end_lon - start_lon)
        points.append((lat, lon))
    
    return points

# 모든 노선에 대해 중간 지점 생성
all_points = []

# 데이터프레임의 각 행(노선)에 대해 처리
for index, row in data.iterrows():
    # 기점과 종점의 좌표 추출
    start_lat = row['기점_위도']
    start_lon = row['기점_경도']
    end_lat = row['종점_위도']
    end_lon = row['종점_경도']
    
    # 현재 노선의 중간 지점들 생성
    route_points = generate_points_every_30m(start_lat, start_lon, end_lat, end_lon)
    
    # 노선 정보와 생성된 지점들을 딕셔너리로 저장
    all_points.append({
        '노선명': row['노선명'],
        '노선번호': row['노선번호'],
        'points': route_points
    })

# 결과 확인 (처음 5개 노선만 출력)
for route in all_points[:5]:
    print(f"노선 {route['노선명']} ({route['노선번호']})")
    print(f"지점들: {route['points']}")
    print()